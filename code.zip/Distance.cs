﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Diagnostics;
using FuzzyString;

namespace MSThesis
{
    class Distance
    {
        public static string CalculateNormalizeDistance(string value, int max)
        {
            try
            {
                double temp = Convert.ToInt32(value) * 100;
                temp = temp / Convert.ToInt32(max);
                temp = Math.Round(temp, 2);
                return temp.ToString();
            }
            catch (Exception ex) { return "0"; }
        }
        public static int GetHammingDistance(string stOne, string stTwo)
        {
            return FuzzyString.ComparisonMetrics.HammingDistance(stOne, stTwo);
        }
        public static int GetDamerauLevenshteinDistance(string source, string target)
        {
            var bounds = new { Height = source.Length + 1, Width = target.Length + 1 };

            int[,] matrix = new int[bounds.Height, bounds.Width];

            for (int height = 0; height < bounds.Height; height++) { matrix[height, 0] = height; };
            for (int width = 0; width < bounds.Width; width++) { matrix[0, width] = width; };

            for (int height = 1; height < bounds.Height; height++)
            {
                for (int width = 1; width < bounds.Width; width++)
                {
                    int cost = (source[height - 1] == target[width - 1]) ? 0 : 1;
                    int insertion = matrix[height, width - 1] + 1;
                    int deletion = matrix[height - 1, width] + 1;
                    int substitution = matrix[height - 1, width - 1] + cost;

                    int distance = Math.Min(insertion, Math.Min(deletion, substitution));

                    if (height > 1 && width > 1 && source[height - 1] == target[width - 2] && source[height - 2] == target[width - 1])
                    {
                        distance = Math.Min(distance, matrix[height - 2, width - 2] + cost);
                    }

                    matrix[height, width] = distance;
                }
            }

            return matrix[bounds.Height - 1, bounds.Width - 1];
        }
        public static int GetLevenshteinDistance(string s, string t)
        {
            try
            {
                int n = s.Length;
                int m = t.Length;
                int[,] d = new int[n + 1, m + 1];

                // Step 1
                if (n == 0)
                {
                    return m;
                }

                if (m == 0)
                {
                    return n;
                }

                // Step 2
                for (int i = 0; i <= n; d[i, 0] = i++)
                {
                }

                for (int j = 0; j <= m; d[0, j] = j++)
                {
                }

                // Step 3
                for (int i = 1; i <= n; i++)
                {
                    //Step 4
                    for (int j = 1; j <= m; j++)
                    {
                        // Step 5
                        int cost = (t[j - 1] == s[i - 1]) ? 0 : 1;

                        // Step 6
                        d[i, j] = Math.Min(
                            Math.Min(d[i - 1, j] + 1, d[i, j - 1] + 1),
                            d[i - 1, j - 1] + cost);
                    }
                }
                // Step 7
                return d[n, m];
            }
            catch (Exception ex) { }
            return 0;
        }
        public static double GetDiceCoefficient(string stOne, string stTwo)
        {
            try
            {
                HashSet<string> nx = new HashSet<string>();
                HashSet<string> ny = new HashSet<string>();

                for (int i = 0; i < stOne.Length - 1; i++)
                {
                    char x1 = stOne[i];
                    char x2 = stOne[i + 1];
                    string temp = x1.ToString() + x2.ToString();
                    nx.Add(temp);
                }
                for (int j = 0; j < stTwo.Length - 1; j++)
                {
                    char y1 = stTwo[j];
                    char y2 = stTwo[j + 1];
                    string temp = y1.ToString() + y2.ToString();
                    ny.Add(temp);
                }

                HashSet<string> intersection = new HashSet<string>(nx);
                intersection.IntersectWith(ny);

                double dbOne = intersection.Count;
                return Math.Round((2 * dbOne) / (nx.Count + ny.Count), 4);
            }
            catch (Exception ex)
            {
                return 0;
            }

        }
        public static double GetJaccardDistance(string stOne, string stTwo)
        {
            try{
            return Math.Round(FuzzyString.ComparisonMetrics.JaccardDistance(stOne, stTwo), 4);
            }
            catch (Exception ex)
            {
                return 0;
            }
        }
        public static double GetJaroDistance(string stOne, string stTwo)
        {
            return FuzzyString.ComparisonMetrics.JaroDistance(stOne, stTwo);
        }
        public static double GetJaroWinklerDistance(string stOne, string stTwo)
        {
            return FuzzyString.ComparisonMetrics.JaroWinklerDistance(stOne, stTwo);
        }
        public static double GetOverlapCoefficient(string stOne, string stTwo)
        {       
            try{
            return Math.Round(FuzzyString.ComparisonMetrics.OverlapCoefficient(stOne, stTwo), 4);
            }
            catch (Exception ex)
            {
                return 0;
            }
        }
        public static double GetRatcliffObershelpSimilarity(string stOne, string stTwo)
        {            
            return Math.Round(FuzzyString.ComparisonMetrics.RatcliffObershelpSimilarity(stOne, stTwo), 4);
        }
        public static double GetSorensenDiceDistance(string stOne, string stTwo)
        {            
            return Math.Round(FuzzyString.ComparisonMetrics.SorensenDiceDistance(stOne, stTwo), 4);
        }
        public static double GetTanimotoCoefficient(string stOne, string stTwo)
        {
            return Math.Round(FuzzyString.ComparisonMetrics.TanimotoCoefficient(stOne, stTwo), 4);            
        }
        public static double GetNgramDistance(string stOne, string stTwo)
        {
            NGramDistance ng = new NGramDistance();            
            return Math.Round(ng.GetDistance(stOne, stTwo), 4);

        }
    }
}
