﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Collections;
using thesis_crawler;

namespace MSThesis
{
    
    
    //simple Vector model 
    //weighted vector model on basics of term frequency
    //assigh the score to each sentence given by maximum matched sentence of abstract sentences
    //assigh the weighted score to each sentence given by maximum matched sentence of abstract sentences
    //the coverage of each sentence of document with the coverage of sentences of abstract
    //assignment of multiplier
    //selection  N top sentences both for IR and summarizer
    //selection of threshold for maximum
    //selection of threshold for minimum

    public partial class Form1 : Form
    {
        
       public static int ThresholdCountMax_final = 70;
       public static int ThresholdCountMin_final = 30;
       public static int VM = 35;
       public static int cluster = 30;
       public static int Coverage = 35;
       
        public Form1()
        {
            InitializeComponent();
        }
        private void label1_Click(object sender, EventArgs e)
        {

        }
        private void upload_Click(object sender, EventArgs e)
        {
            string file = @filePath.Text;
            string absPath = @abstractPath.Text;
           // processFile(file, absPath,"no");
        }
        private void Select_Click(object sender, EventArgs e)
        {
            DialogResult result = openFileDialog1.ShowDialog();
            if (result == DialogResult.OK) // Test result.
            {
                filePath.Text = openFileDialog1.FileName;
            }
        }
        private void processFile(string fileName, string abstractPath, string isSaveDB, DBConnect Dbconnection, string status, int max, int min, string file_id)
        {
           
            int N = 5;//select top N sentences from each algo// set to abstract length x4
            string file = fileName;
            string abstractP = abstractPath;
            if (File.Exists(file) && File.Exists(abstractP))
            {
                string corpus = File.ReadAllText(file);
                string corpusAbs = File.ReadAllText(abstractPath);
                if (corpus.Contains('.'))
                {
                    string[] sentences;
                    sentences = corpus.Split('.');
                  //  N = Convert.ToInt32(( sentences.Length * 1.5));                    
                    DataTable datatable = new DataTable();
                    datatable = Data_table.datatableColumnsinit(datatable);
                    datatable = Parameters.FindParameters(corpus, datatable, sentences, corpusAbs);
                    datatable = Parser.NormalizeParameters(datatable);
                    //displaying score of each sentence using both Summarizer and IR techniques
                    gridSummarizer.DataSource = Weight.getDTweightedSummarizer(datatable);
                    gridIR.DataSource = Weight.getDTweightedIR(datatable);
                    //things to show in final dt
#region //AC255034// commenting this just to find corrected weights for summarization
                    int MaxThresholdcountSummarizer = Weight.getThresholdScoreMaxCount(Weight.getDTweightedSummarizer(datatable), ThresholdCountMax_final);
                    int MaxThresholdcountIR = Weight.getThresholdScoreMaxCount(Weight.getDTweightedIR(datatable), ThresholdCountMax_final);
                    int MinThresholdcountSummarizer = Weight.getThresholdScoreMinCount(Weight.getDTweightedSummarizer(datatable), ThresholdCountMin_final);
                    int MinThresholdcountIR = Weight.getThresholdScoreMinCount(Weight.getDTweightedIR(datatable), ThresholdCountMin_final);
                    int CommonSentences = Weight.CommonSentencesBetweenDTs(Data_table.SelectTopNrows(Weight.getDTweightedSummarizer(datatable), N), Data_table.SelectTopNrows(Weight.getDTweightedIR(datatable), N));
                    string top2Nsentences = Weight.UnionCorpus(Data_table.SelectTopNrows(Weight.getDTweightedSummarizer(datatable), N), Data_table.SelectTopNrows(Weight.getDTweightedIR(datatable), N));
                   // gridFinalScores.DataSource = Weight.getFinalDistances(corpusAbs, top2Nsentences, MaxThresholdcountIR, MaxThresholdcountSummarizer, MinThresholdcountIR, MinThresholdcountSummarizer, CommonSentences);
#endregion                     
                    //following below line will below used to insert into DB, while above line will be used to display in grid
                    getDatabaseFinalDistances(corpusAbs, top2Nsentences, MaxThresholdcountIR, MaxThresholdcountSummarizer, MinThresholdcountIR, MinThresholdcountSummarizer, CommonSentences, Dbconnection, status, file_id);
                }
            }
            else { MessageBox.Show("file not exist"); }
        }
        private void button1_Click(object sender, EventArgs e)
        {
            DialogResult result1 = openFileDialog2.ShowDialog();
            if (result1 == DialogResult.OK) // Test result.
            {
                abstractPath.Text = openFileDialog2.FileName;
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

            filePath.Text = @"E:\TD work\OPEN\MS\Semester 3\Thesis 1\Thesis\MSThesisMine\Documentation\Sample Corpus\good\cor.txt";
            abstractPath.Text = @"E:\TD work\OPEN\MS\Semester 3\Thesis 1\Thesis\MSThesisMine\Documentation\Sample Corpus\good\abs.txt";
            
            //filePath.Text = @"E:\TD work\OPEN\MS\symester 4\Thesis 2\MSThesisMine\Documentation\dataset\new_dataset\post_processed\strong\done\train\SSRN-id1871\SSRN-id1871_filltext.txt";
            //abstractPath.Text = @"E:\TD work\OPEN\MS\symester 4\Thesis 2\MSThesisMine\Documentation\dataset\new_dataset\post_processed\strong\done\train\SSRN-id1871\SSRN-id1871_abstract.txt";
            dirPath.Text = @"E:\TD work\OPEN\MS\symester 4\Thesis 2\dataset\new_dataset\post_processed\strong\done\train\";//for training
            dirPath.Text = @"E:\TD work\OPEN\MS\symester 4\Thesis 2\dataset\new_dataset\post_processed\strong\done\test\";//for testing
        }

        private void button2_Click(object sender, EventArgs e)
        {
            DBConnect Dbconnection = new DBConnect();
            Dbconnection.OpenConnection();
           // for (int XX = 0; XX < 2; XX++)
            {
             //   if (XX == 0) { clusterXX = 100; clusterXXW = 0;  }
               // if (XX == 1) { clusterXX = 0; clusterXXW = 100; }
          //      if (XX == 0) { Weight.clusterXX = 0; Weight.clusterYY = 0; Weight.clusterZZ = 100; }
           //     if (XX == 2) { Weight.clusterXX = 100; Weight.clusterYY = 0; Weight.clusterZZ = 0; }
           //     if (XX == 1) { Weight.clusterXX = 0; Weight.clusterYY = 100; Weight.clusterZZ = 0; }
                

               
                    string DirPaTh = @dirPath.Text;
                    
                    string status = "high";
                    string[] folders = Directory.GetDirectories(DirPaTh);
                    foreach (string folder in folders)
                    {
                        try
                        {                           
                            string file_id = folder.Split('\\').Last();
                            string file = folder + @"\" + file_id + "_abstract.txt";
                            string absPath = folder + @"\" + file_id + "_filltext.txt";
                            processFile(file, absPath, "no", Dbconnection, status, ThresholdCountMax_final, ThresholdCountMin_final, file_id);
                        }
                        catch (Exception es) { }                       
                    }
                    DirPaTh = @dirPath.Text.Replace("strong", "weak");
                    
                    status = "low";
                    folders = Directory.GetDirectories(DirPaTh);
                    foreach (string folder in folders)
                    {
                        try
                        {
                            string file_id = folder.Split('\\').Last();
                            string file = folder + @"\" + file_id + "_abstract.txt";
                            string absPath = folder + @"\" + file_id + "_filltext.txt";
                            processFile(file, absPath, "no", Dbconnection, status, ThresholdCountMax_final, ThresholdCountMin_final, file_id);
                        }
                        catch (Exception ea) { }
                    }
                
            }
            Dbconnection.CloseConnection();
            MessageBox.Show("Error");
            

        }
        public static void getDatabaseFinalDistances(string corpusAbs, string top2Nsentences, int thresholdcountIRMax, int thresholdcountSummarizerMax, int thresholdcountIRMin, int thresholdcountSummarizerMin, int CommonSentences, DBConnect Dbconnection, string status, string file_id)
        {
            corpusAbs = Parser.parse_Sentence(corpusAbs);
            top2Nsentences = Parser.parse_Sentence(top2Nsentences);
            corpusAbs = Parser.remove_fullStop(corpusAbs);
            top2Nsentences = Parser.remove_fullStop(top2Nsentences);
            /*
            DataTable dt = new DataTable();
            dt.Columns.Add("ThresholdCountIRMax");
            dt.Columns.Add("thresholdcountSummarizerMax");
            dt.Columns.Add("ThresholdCountIRMin");
            dt.Columns.Add("thresholdcountSummarizerMin");
            dt.Columns.Add("CommonSentences");
            dt.Columns.Add("HammingD");            
            dt.Columns.Add("LevenshteinD");
            dt.Columns.Add("DiceC");
            dt.Columns.Add("JaccardD");
            //dt.Columns.Add("JaroD");
            //dt.Columns.Add("JaroWinklerD");
            dt.Columns.Add("OverlapC");
            dt.Columns.Add("RatcliffObershelpS");
            dt.Columns.Add("SorensenDiceD");
            dt.Columns.Add("TanimotoC");
            dt.Columns.Add("NgramD");

            DataRow newRR = dt.NewRow();

            newRR["ThresholdCountIRMax"] = thresholdcountIRMax;
            newRR["thresholdcountSummarizerMax"] = thresholdcountSummarizerMax;
            newRR["ThresholdCountIRMin"] = thresholdcountIRMin;
            newRR["thresholdcountSummarizerMin"] = thresholdcountSummarizerMin;
            newRR["CommonSentences"] = CommonSentences;
            // newRR["HammingD"] = Distance.GetHammingDistance(corpusAbs, top2Nsentences);            
            newRR["LevenshteinD"] = Distance.GetLevenshteinDistance(corpusAbs, top2Nsentences);
            newRR["DiceC"] = Distance.GetDiceCoefficient(corpusAbs, top2Nsentences);
            newRR["JaccardD"] = Distance.GetJaccardDistance(corpusAbs, top2Nsentences);
            //below two takes more time, comment them
            //  newRR["JaroD"] = Distance.GetJaroDistance(corpusAbs, top2Nsentences);
            // newRR["JaroWinklerD"] = Distance.GetJaroWinklerDistance(corpusAbs, top2Nsentences);
            newRR["OverlapC"] = Distance.GetOverlapCoefficient(corpusAbs, top2Nsentences);
            newRR["RatcliffObershelpS"] = Distance.GetRatcliffObershelpSimilarity(corpusAbs, top2Nsentences);
            newRR["SorensenDiceD"] = Distance.GetSorensenDiceDistance(corpusAbs, top2Nsentences);
            newRR["TanimotoC"] = Distance.GetTanimotoCoefficient(corpusAbs, top2Nsentences);
            newRR["NgramD"] = Distance.GetNgramDistance(corpusAbs, top2Nsentences);
            */

            string Leven = Distance.GetLevenshteinDistance(corpusAbs, top2Nsentences).ToString();
            string Jaccard = Distance.GetJaccardDistance(corpusAbs, top2Nsentences).ToString();
            string Rar = Distance.GetRatcliffObershelpSimilarity(corpusAbs, top2Nsentences).ToString();
            string soren = Distance.GetSorensenDiceDistance(corpusAbs, top2Nsentences).ToString();
            string ngram = Distance.GetNgramDistance(corpusAbs, top2Nsentences).ToString();

            string LevenStatus = "med";
            string JaccardStatus = "med";
            string RarStatus = "med";
            string sorenStatus = "med";
            string ngramStatus = "Normal";

            if (Convert.ToDouble(Leven) > 78290)
            {LevenStatus = "high";}
            else if (Convert.ToDouble(Leven) < 45000) { LevenStatus = "low"; }

            if (Convert.ToDouble(Jaccard) > 0.41)
            {JaccardStatus = "low";}
            else if (Convert.ToDouble(Jaccard) < 0.2500) { JaccardStatus = "high"; }

            if (Convert.ToDouble(ngram) > 0.058)
            {
                ngramStatus = "extractive";
            }

            if (Convert.ToDouble(Rar) > 0.002000)
            {
                RarStatus = "low";
            }
            else if (Convert.ToDouble(Rar) < 0.0013) { RarStatus = "high"; }

            if (Convert.ToDouble(soren) < 0.99820)
            {
                sorenStatus = "low";
            }
            else if (Convert.ToDouble(soren) > 0.998800) { sorenStatus = "high"; }


            string FStatus = getStatus(LevenStatus, JaccardStatus, RarStatus, sorenStatus);


            int id = Dbconnection.getNextid("summary_weights", "id");
            Console.WriteLine("Processing : " + id.ToString());

            Dbconnection.InsertSummryWeights(id, file_id,status, ThresholdCountMax_final.ToString()+"_" + ThresholdCountMin_final.ToString() +"_"+ VM + "_" + cluster+"_"+ Coverage, 
                 thresholdcountIRMax.ToString(),
                 thresholdcountSummarizerMax.ToString(),
                 thresholdcountIRMin.ToString(),
                 thresholdcountSummarizerMin.ToString(),
                 CommonSentences.ToString(), /*"0", "0", "0", "0", "0", "0", "0", "0"*/
                 Leven,
                 FStatus,
                Jaccard,
                 "",
                 Rar,
                 soren,
                 ngramStatus, 
                 ngram
                 );
            

            
         //   dt.Rows.Add(newRR);
           
        }
        private static string getStatus(string LevenStatus, string JaccardStatus, string RarStatus, string sorenStatus)
        {

            if(LevenStatus==JaccardStatus && (JaccardStatus=="low" || JaccardStatus=="high"))
            { return LevenStatus; }

         
            
            int highCount = 0;
            int lowCount = 0;            

            if (LevenStatus == "high")
            { highCount++; }
            else if (LevenStatus == "low") { lowCount++; }

            if (JaccardStatus == "high")
            { highCount++; }
            else if (JaccardStatus == "low") { lowCount++; }

            if (RarStatus == "high")
            { highCount++; }
            else if (RarStatus == "low") { lowCount++; }

            if (sorenStatus == "high")
            { highCount++; }
            else if (sorenStatus == "low") { lowCount++; }


            if (highCount > lowCount) { return "high"; }
            if (highCount < lowCount) { return "low"; }
            if (highCount == lowCount) { return "medium"; } else { return "medium"; }
        }
    }
}
