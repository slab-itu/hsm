﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;

namespace MSThesis
{
    class Weight
    {
       //
        public static DataTable multiplier_Summarizer(DataTable iitable, double TF_m, double posinDoc_m, double g_len_m)
        {
            DataTable dt = new DataTable();
            dt.Columns.Add("Score");
            dt.Columns.Add("ORGSentence");
            dt.Columns.Add("ParsedSentence");
            dt.Columns.Add("TF");
            dt.Columns.Add("PID");
            dt.Columns.Add("SLength");
            foreach (DataRow row in iitable.Rows)
            {
                double score = 0;
                score = (TF_m * Convert.ToDouble(row["TF"])) + (posinDoc_m * Convert.ToDouble(row["PID"])) + (g_len_m * Convert.ToDouble(row["SLength"]));
                score = score / 100;
                score = Math.Round(score, 2);
                DataRow newRR = dt.NewRow();
                newRR["Score"] = score;
                newRR["ORGSentence"] = row["ORGSentence"];
                newRR["ParsedSentence"] = row["ParsedSentence"];
                newRR["TF"] = row["TF"];
                newRR["PID"] = row["PID"];
                newRR["SLength"] = row["SLength"];
                dt.Rows.Add(newRR);
            }
            dt = Data_table.SortDataTable(dt);
            return dt;
        }
        public static DataTable multiplier_IR(DataTable iitable, double VM_m, double WVM_m, double clustersW_m, double clusters_m, double clustersCoverage_m)
        {
            DataTable dt = new DataTable();
            dt.Columns.Add("Score");
            dt.Columns.Add("ORGSentence");
            dt.Columns.Add("ParsedSentence");
            dt.Columns.Add("VM");
            dt.Columns.Add("WVM");
            dt.Columns.Add("clustersW");
            dt.Columns.Add("clusters");
            dt.Columns.Add("clustersCoverage");
            foreach (DataRow row in iitable.Rows)
            {
                double score = 0;
                score = (VM_m * Convert.ToDouble(row["VM"])) + (WVM_m * Convert.ToDouble(row["WVM"])) + (clustersW_m * Convert.ToDouble(row["clustersW"])) + (clusters_m * Convert.ToDouble(row["clusters"])) + (clustersCoverage_m * Convert.ToDouble(row["clustersCoverage"]));
                score = score / 100;
                score = Math.Round(score, 2);
                DataRow newRR = dt.NewRow();
                newRR["Score"] = score;
                newRR["ORGSentence"] = row["ORGSentence"];
                newRR["ParsedSentence"] = row["ParsedSentence"];
                newRR["VM"] = row["VM"];
                newRR["WVM"] = row["WVM"];
                newRR["clustersW"] = row["clustersW"];
                newRR["clusters"] = row["clusters"];
                newRR["clustersCoverage"] = row["clustersCoverage"];
                dt.Rows.Add(newRR);
            }
            dt = Data_table.SortDataTable(dt);
            return dt;
        }
        public static DataTable getDTweightedSummarizer(DataTable idt)
        {
            double TF_m = 40,  g_len_m = 30,posinDoc_m = 30;
            return multiplier_Summarizer(idt, TF_m, posinDoc_m, g_len_m);

        }
        public static DataTable getDTweightedIR(DataTable idt)
        {
            double VM_m = 0, WVM_m = 0, clustersW_m = 0, clusters_m = 0, clustersCoverage_m = 0; ;
            VM_m = Form1.VM; clustersW_m = Form1.cluster; clustersCoverage_m = Form1.Coverage;
            return multiplier_IR(idt, VM_m, WVM_m, clustersW_m, clusters_m, clustersCoverage_m);

        }
        public static string UnionCorpus(DataTable fdt, DataTable sdt)
        {
            string result = "";
            foreach (DataRow row in fdt.Rows)
            {
                result = result + row["ORGSentence"] + ".";
            }
            foreach (DataRow row in sdt.Rows)
            {
                result = result + row["ORGSentence"] + ".";
            }

            return result;
        }
        public static string datatableToString(DataTable fdt)
        {
            string result = "";
            foreach (DataRow row in fdt.Rows)
            {
                result = result + row["ORGSentence"] + ".";
            }            

            return result;
        }
        public static int CommonSentencesBetweenDTs(DataTable fdt, DataTable sdt)
        {
            int result = 0;
            foreach (DataRow frow in fdt.Rows)
            {
                foreach (DataRow srow in sdt.Rows)
                {
                    if (frow["ORGSentence"] == srow["ORGSentence"] || frow["ParsedSentence"] == srow["ParsedSentence"])
                        result++;
                }
            }
            return result;
        }
        public static int getThresholdScoreMaxCount(DataTable fdt, int threshold)
        {
            int result = 0;
            foreach (DataRow frow in fdt.Rows)
            {
                if (Convert.ToDouble(frow["Score"]) >= threshold)
                {
                    result++;
                }
            }
            return result*100;
        }
        public static int getThresholdScoreMinCount(DataTable fdt, int threshold)
        {
            int result = 0;
            foreach (DataRow frow in fdt.Rows)
            {
                if (Convert.ToDouble(frow["Score"]) <= threshold)
                {
                    result++;
                }
            }
            result++;
            return (1000/result);
        }
        public static DataTable getFinalDistances(string corpusAbs, string top2Nsentences, int thresholdcountIRMax, int thresholdcountSummarizerMax, int thresholdcountIRMin, int thresholdcountSummarizerMin, int CommonSentences)
        {
            corpusAbs =Parser.parse_Sentence(corpusAbs);
            top2Nsentences = Parser.parse_Sentence(top2Nsentences);
            corpusAbs = Parser.remove_fullStop(corpusAbs);
            top2Nsentences = Parser.remove_fullStop(top2Nsentences);

            DataTable dt = new DataTable();
            dt.Columns.Add("ThresholdCountIRMax");
            dt.Columns.Add("thresholdcountSummarizerMax");
            dt.Columns.Add("ThresholdCountIRMin");
            dt.Columns.Add("thresholdcountSummarizerMin");
            dt.Columns.Add("CommonSentences");
            //dt.Columns.Add("HammingD");            
            dt.Columns.Add("LevenshteinD");
            dt.Columns.Add("DiceC");
            dt.Columns.Add("JaccardD");
            //dt.Columns.Add("JaroD");
            //dt.Columns.Add("JaroWinklerD");
            dt.Columns.Add("OverlapC");
            dt.Columns.Add("RatcliffObershelpS");
            dt.Columns.Add("SorensenDiceD");
            dt.Columns.Add("TanimotoC");
            dt.Columns.Add("NgramD");

            DataRow newRR = dt.NewRow();

            newRR["ThresholdCountIRMax"] = thresholdcountIRMax;
            newRR["thresholdcountSummarizerMax"] = thresholdcountSummarizerMax;
            newRR["ThresholdCountIRMin"] = thresholdcountIRMin;
            newRR["thresholdcountSummarizerMin"] = thresholdcountSummarizerMin;
            newRR["CommonSentences"] = CommonSentences;
           // newRR["HammingD"] = Distance.GetHammingDistance(corpusAbs, top2Nsentences);            
            newRR["LevenshteinD"] = Distance.GetLevenshteinDistance(corpusAbs, top2Nsentences);
            newRR["DiceC"] = Distance.GetDiceCoefficient(corpusAbs, top2Nsentences);
            newRR["JaccardD"] = Distance.GetJaccardDistance(corpusAbs, top2Nsentences);
            //below two takes more time, comment them
          //  newRR["JaroD"] = Distance.GetJaroDistance(corpusAbs, top2Nsentences);
           // newRR["JaroWinklerD"] = Distance.GetJaroWinklerDistance(corpusAbs, top2Nsentences);
            newRR["OverlapC"] = Distance.GetOverlapCoefficient(corpusAbs, top2Nsentences);
            newRR["RatcliffObershelpS"] = Distance.GetRatcliffObershelpSimilarity(corpusAbs, top2Nsentences);
            newRR["SorensenDiceD"] = Distance.GetSorensenDiceDistance(corpusAbs, top2Nsentences);
            newRR["TanimotoC"] = Distance.GetTanimotoCoefficient(corpusAbs, top2Nsentences);
            newRR["NgramD"] = Distance.GetNgramDistance(corpusAbs, top2Nsentences);

            dt.Rows.Add(newRR);
            return dt;
        }

    }
}
