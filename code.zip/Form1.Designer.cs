﻿namespace MSThesis
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.filePath = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.Select = new System.Windows.Forms.Button();
            this.gridSummarizer = new System.Windows.Forms.DataGridView();
            this.openFileDialog2 = new System.Windows.Forms.OpenFileDialog();
            this.label2 = new System.Windows.Forms.Label();
            this.abstractPath = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.upload = new System.Windows.Forms.Button();
            this.gridIR = new System.Windows.Forms.DataGridView();
            this.gridFinalScores = new System.Windows.Forms.DataGridView();
            this.dirPath = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.gridSummarizer)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridIR)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridFinalScores)).BeginInit();
            this.SuspendLayout();
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // filePath
            // 
            this.filePath.Location = new System.Drawing.Point(144, 70);
            this.filePath.Name = "filePath";
            this.filePath.Size = new System.Drawing.Size(421, 20);
            this.filePath.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(96, 70);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(35, 13);
            this.label1.TabIndex = 2;
            this.label1.Text = "Paper";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // Select
            // 
            this.Select.Location = new System.Drawing.Point(571, 70);
            this.Select.Name = "Select";
            this.Select.Size = new System.Drawing.Size(75, 23);
            this.Select.TabIndex = 3;
            this.Select.Text = "Select";
            this.Select.UseVisualStyleBackColor = true;
            this.Select.Click += new System.EventHandler(this.Select_Click);
            // 
            // gridSummarizer
            // 
            this.gridSummarizer.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gridSummarizer.Location = new System.Drawing.Point(144, 141);
            this.gridSummarizer.Name = "gridSummarizer";
            this.gridSummarizer.Size = new System.Drawing.Size(1133, 160);
            this.gridSummarizer.TabIndex = 5;
            // 
            // openFileDialog2
            // 
            this.openFileDialog2.FileName = "openFileDialog2";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(85, 99);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(46, 13);
            this.label2.TabIndex = 6;
            this.label2.Text = "Abstract";
            // 
            // abstractPath
            // 
            this.abstractPath.Location = new System.Drawing.Point(144, 96);
            this.abstractPath.Name = "abstractPath";
            this.abstractPath.Size = new System.Drawing.Size(421, 20);
            this.abstractPath.TabIndex = 7;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(571, 96);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 22);
            this.button1.TabIndex = 8;
            this.button1.Text = "Select";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // upload
            // 
            this.upload.Location = new System.Drawing.Point(652, 70);
            this.upload.Name = "upload";
            this.upload.Size = new System.Drawing.Size(75, 47);
            this.upload.TabIndex = 0;
            this.upload.Text = "singleFile";
            this.upload.UseVisualStyleBackColor = true;
            this.upload.Click += new System.EventHandler(this.upload_Click);
            // 
            // gridIR
            // 
            this.gridIR.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gridIR.Location = new System.Drawing.Point(144, 307);
            this.gridIR.Name = "gridIR";
            this.gridIR.Size = new System.Drawing.Size(1133, 164);
            this.gridIR.TabIndex = 9;
            // 
            // gridFinalScores
            // 
            this.gridFinalScores.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gridFinalScores.Location = new System.Drawing.Point(144, 477);
            this.gridFinalScores.Name = "gridFinalScores";
            this.gridFinalScores.Size = new System.Drawing.Size(1133, 164);
            this.gridFinalScores.TabIndex = 10;
            // 
            // dirPath
            // 
            this.dirPath.Location = new System.Drawing.Point(144, 44);
            this.dirPath.Name = "dirPath";
            this.dirPath.Size = new System.Drawing.Size(421, 20);
            this.dirPath.TabIndex = 11;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(96, 44);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(39, 13);
            this.label3.TabIndex = 12;
            this.label3.Text = "Dir File";
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(733, 71);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 47);
            this.button2.TabIndex = 13;
            this.button2.Text = "DirProcess";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(887, 80);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(35, 13);
            this.label4.TabIndex = 14;
            this.label4.Text = "label4";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1358, 882);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.dirPath);
            this.Controls.Add(this.gridFinalScores);
            this.Controls.Add(this.gridIR);
            this.Controls.Add(this.gridSummarizer);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.abstractPath);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.Select);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.filePath);
            this.Controls.Add(this.upload);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.gridSummarizer)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridIR)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridFinalScores)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.TextBox filePath;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button Select;
        private System.Windows.Forms.DataGridView gridSummarizer;
        private System.Windows.Forms.OpenFileDialog openFileDialog2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox abstractPath;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button upload;
        private System.Windows.Forms.DataGridView gridIR;
        private System.Windows.Forms.DataGridView gridFinalScores;
        private System.Windows.Forms.TextBox dirPath;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label4;
    }
}

