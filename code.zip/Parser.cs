﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Data;

namespace MSThesis
{
    class Parser
    {
        public static string remove_stopwords(string file)
        {
            string newFile = file.ToLower();
         /*
            newFile = Regex.Replace(newFile, @"\n|\r", "");
            string[] stopwords = {"and","any", "of","the", "them", "they", "for", "we", "so", "should", "on", "in","by", 
                                     "if", "there", "here", "had", "has", "how", "i", "her", "him", "his", "she", 
                                     "he", "too", "to", "be","at","aren't","as","is","are","the","a","an","of",
                                     "you","your","who","how","whome","which","why","what","with","would","such",
                                     "that","than","then","should","some","own","me","my","it","or","all","due",
                                     "ie","did","do","does","can","only","other","1","2","3","4","5","6","7","8","9","0","www"
                                 };
            foreach (string word in stopwords)
            {
                newFile = newFile.Replace(" " + word + " ", " ");
            }
          * */
            return newFile;
        }
        public static string remove_specialCharacters(string file)
        {
            string newFile = file.ToLower();
            newFile = Regex.Replace(newFile, @"\n|\r", "");

            string[] specChar = { ",", ".", "~", "!", "@", "#", "$", "%", "^", "&", "*", "(", ")", "_", "-", "+", "=", "/", "'", ";", ":", "`", "?", ">", "<", "|", "\"" };
            foreach (string word in specChar)
            {
                newFile = newFile.Replace(word, " ");
            }
            return newFile;
        }
        public static string remove_fullStop(string file)
        {
            string newFile = file.ToLower();
            newFile = Regex.Replace(newFile, @"\n|\r", "");
            newFile = newFile.Replace(".", " ");
            return newFile;
        }
        public static string parse_Sentence(string sentence)
        {

            string parsed_sen = Parser.remove_specialCharacters(sentence);
            parsed_sen = Parser.remove_stopwords(parsed_sen);
            return parsed_sen;
        }
        public static DataTable NormalizeParameters(DataTable dts)
        {
            int MTF = 0, MSLength = 0, MPID = 0, MVM = 0, MWVM = 0, MclustersW = 0, Mclusters = 0, MclustersCoverage = 0;
            #region // code to get max value
            foreach (DataRow dr in dts.Rows)
            {
                int TF = Convert.ToInt32(dr.Field<string>("TF"));
                int SLength = Convert.ToInt32(dr.Field<string>("SLength"));
                int PID = Convert.ToInt32(dr.Field<string>("PID"));
                int VM = Convert.ToInt32(dr.Field<string>("VM"));
                int WVM = Convert.ToInt32(dr.Field<string>("WVM"));
                int clustersW = Convert.ToInt32(dr.Field<string>("clustersW"));
                int clusters = Convert.ToInt32(dr.Field<string>("clusters"));
                int clustersCoverage = Convert.ToInt32(dr.Field<string>("clustersCoverage"));

                MTF = Math.Max(MTF, TF);
                MSLength = Math.Max(MSLength, SLength);
                MPID = Math.Max(MPID, PID);
                MVM = Math.Max(MVM, VM);
                MWVM = Math.Max(MWVM, WVM);
                MclustersW = Math.Max(MclustersW, clustersW);
                Mclusters = Math.Max(Mclusters, clusters);
                MclustersCoverage = Math.Max(MclustersCoverage, clustersCoverage);
            }
            #endregion
            #region // code to normalize
            for (int i = 0; i < dts.Rows.Count; i++)
            {
                dts.Rows[i]["ORGSentence"] = dts.Rows[i]["ORGSentence"];
                dts.Rows[i]["ParsedSentence"] = dts.Rows[i]["ParsedSentence"];
                dts.Rows[i]["TF"] = Distance.CalculateNormalizeDistance(dts.Rows[i]["TF"].ToString(), MTF);
                dts.Rows[i]["SLength"] = Distance.CalculateNormalizeDistance(dts.Rows[i]["SLength"].ToString(), MSLength);
                dts.Rows[i]["PID"] = Distance.CalculateNormalizeDistance(dts.Rows[i]["PID"].ToString(), MPID);
                dts.Rows[i]["VM"] = Distance.CalculateNormalizeDistance(dts.Rows[i]["VM"].ToString(), MVM);
                dts.Rows[i]["WVM"] = Distance.CalculateNormalizeDistance(dts.Rows[i]["WVM"].ToString(), MWVM);
                dts.Rows[i]["clustersW"] = Distance.CalculateNormalizeDistance(dts.Rows[i]["clustersW"].ToString(), MclustersW);
                dts.Rows[i]["clusters"] = Distance.CalculateNormalizeDistance(dts.Rows[i]["clusters"].ToString(), Mclusters);
                dts.Rows[i]["clustersCoverage"] = Distance.CalculateNormalizeDistance(dts.Rows[i]["clustersCoverage"].ToString(), MclustersCoverage);
            }
            #endregion
            return dts;
        }

    }
}
