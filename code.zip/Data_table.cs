﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;

namespace MSThesis
{
    class Data_table
    {
        public static DataTable SortDataTable(DataTable dt)
        {
            DataView dv = dt.DefaultView;
            dv.Sort = "Score desc";
            DataTable sortedDT = dv.ToTable();
            return sortedDT;
        }
        public static DataTable SelectTopNrows(DataTable dt, int N)
        {
            return dt.Rows.Cast<System.Data.DataRow>().Take(N).CopyToDataTable();
        }
        public static DataTable datatableColumnsinit(DataTable dt)
        {
            try
            {
                dt.Columns.Add("ORGSentence");
                dt.Columns.Add("ParsedSentence");
                dt.Columns.Add("TF");
                dt.Columns.Add("SLength");
                dt.Columns.Add("PID");
                dt.Columns.Add("VM");
                dt.Columns.Add("WVM");
                dt.Columns.Add("clustersW");
                dt.Columns.Add("clusters");
                dt.Columns.Add("clustersCoverage");

                return dt;
            }
            catch (Exception ex)
            { throw ex; }
        }
        public static DataRow datatablefilling(DataRow dRow, int ColumnNameval, string ColumnValue)
        {
            try
            {
                switch (ColumnNameval)
                {
                    case 0:
                        dRow["ORGSentence"] = ColumnValue;
                        break;
                    case 1:
                        dRow["ParsedSentence"] = ColumnValue;
                        break;
                    case 2:
                        dRow["TF"] = ColumnValue;
                        break;
                    case 3:
                        dRow["SLength"] = ColumnValue;
                        break;
                    case 4:
                        dRow["PID"] = ColumnValue;
                        break;
                    case 6:
                        dRow["VM"] = ColumnValue;
                        break;
                    case 8:
                        dRow["WVM"] = ColumnValue;
                        break;
                    case 9:
                        dRow["clustersW"] = ColumnValue;
                        break;
                    case 10:
                        dRow["clusters"] = ColumnValue;
                        break;
                    case 11:
                        dRow["clustersCoverage"] = ColumnValue;
                        break;
                }
                return dRow;
            }
            catch (Exception ex)
            { throw ex; }

        }
        public static DataTable CloneTable(DataTable originalTable)
        {

            DataTable newTable;
            newTable = originalTable.Clone();
            return newTable;

        }
    }
}
