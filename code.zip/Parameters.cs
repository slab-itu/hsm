﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.IO;
using System.Text.RegularExpressions;
using System.Collections;

namespace MSThesis
{
    class Parameters
    {
        public static Hashtable DocumentTF(string doc)
        {
            string parsed_corpus = Parser.remove_specialCharacters(doc);
            parsed_corpus = Parser.remove_stopwords(parsed_corpus);
            parsed_corpus = Parser.remove_fullStop(parsed_corpus);
            Hashtable hash = new Hashtable();
            if (!String.IsNullOrEmpty(parsed_corpus))
            {
                string[] list = parsed_corpus.Split(' ');
                foreach (string word in list)
                {
                    if (hash.ContainsKey(word))
                    {
                        if (word != "")
                        {
                            hash[word] = Convert.ToInt32(hash[word]) + 1;
                        }
                    }
                    else
                    {
                        hash[word] = 1;
                    }
                }
                int my_total = 0;
                foreach (DictionaryEntry entry in hash)
                {
                    my_total = my_total + Convert.ToInt32(entry.Value);
                }
                hash["my_total"] = my_total;
            }
            return hash;
        }
        public static DataTable FindParameters(string Corpus, DataTable dts, string[] sentences, string abstractP)
        {
            try
            {
                int index = 0;
                string parsed_corpus = Parser.remove_specialCharacters(Corpus);
                parsed_corpus = Parser.remove_stopwords(parsed_corpus);
                Hashtable hashTableTF = Parameters.DocumentTF(Corpus);
                foreach (string sen in sentences)
                {
                    string null_sen = sen.Replace(" ", "");
                    null_sen = null_sen.Trim();
                    if (null_sen != "" && !String.IsNullOrEmpty(null_sen) && null_sen.Length>3)
                    {
                        DataRow dataRow = dts.NewRow();
                        dataRow = Data_table.datatablefilling(dataRow, 0, sen);
                        dataRow = Data_table.datatablefilling(dataRow, 1, Parser.parse_Sentence(sen));
                        dataRow = Data_table.datatablefilling(dataRow, 2, term_frequency(sen, hashTableTF).ToString());
                        dataRow = Data_table.datatablefilling(dataRow, 3, sentence_length(Parser.parse_Sentence(sen)).ToString());
                        dataRow = Data_table.datatablefilling(dataRow, 4, PositionInDocument(sentences.Length - 1, index).ToString());
                        dataRow = Data_table.datatablefilling(dataRow, 6, Relation_headline(abstractP, sen).ToString());
                        dataRow = Data_table.datatablefilling(dataRow, 8, Relation_headlineWVM(abstractP, sen, hashTableTF).ToString());
                        dataRow = Data_table.datatablefilling(dataRow, 9, Relation_headlineClusterW(abstractP, sen, hashTableTF).ToString());
                        dataRow = Data_table.datatablefilling(dataRow, 10,Relation_headlineCluster(abstractP, sen, hashTableTF).ToString());
                        dataRow = Data_table.datatablefilling(dataRow, 11,Relation_headlineClusterCount(abstractP, sen, hashTableTF).ToString());
                        dts.Rows.Add(dataRow);
                    }
                    index++;
                }
                return dts;
            }                
            catch (Exception ex)
            { throw ex; }
        }
        public static int Document_Words(string CorpusData)
        {
            try
            {
                string[] document_sentences = CorpusData.Split(' ');
                return document_sentences.Length;
            }
            catch (Exception ex)
            { throw ex; }

        }
        public static int PositionInDocument(int CorpusLength, int sentencePosition)
        {
            try
            {
                double a = 0;
                double div;
                double b = 0;
                a = sentencePosition * sentencePosition;
                div = CorpusLength * CorpusLength;
                a = 190 * a;
                a = a / div;
                b = -215 * sentencePosition;
                b = b / CorpusLength;
                double func = a + b + 100;
                func = Math.Floor(func);
                return (int)func;
            }
            catch (Exception ex)
            { throw ex; }
        }
        public static int term_frequency(string sentence, Hashtable ht)
        {
            try
            {
                sentence = Parser.parse_Sentence(sentence);
                string[] texts = sentence.Split(' ');
                int score = 0;
                double temp = 0;
                foreach (string term in texts)
                {
                    double testRes = 10000 * Convert.ToInt32(ht[term.Replace(" ", "").ToLower()]) / Convert.ToInt32(ht["my_total"]);
                    temp = temp + testRes;
                }
                temp = Math.Round(temp);
                score = (int)temp;
                return score;
            }
            catch (Exception ex)
            { throw ex; }
        }
        public static int sentence_length(string sentence)
        {
            try
            {
                double len = 0;
                string[] text = sentence.Split(' ');
                len = text.Length;
                len = Math.Round(len);
                return (int)len;
            }
            catch (Exception ex)
            { throw ex; }
        }
        public static int Relation_headline(string fsentence, string xSentence)
        {
            try
            {
                fsentence = Parser.parse_Sentence(fsentence);
                xSentence = Parser.parse_Sentence(xSentence);
                fsentence = Parser.remove_fullStop(fsentence);
                xSentence = Parser.remove_fullStop(xSentence);
                string[] text = fsentence.Split(' ');
                string[] list = xSentence.Split(' ');
                string dummyString = "";
                int freq = 0;
                int score = 0;
                double temp = 0;
                for (int i = 0; i < text.Length; i++)
                {
                    for (int j = 0; j < list.Length; j++)
                    {

                        if (isEqualStrings(text[i].ToString(), list[j].ToString()) && !dummyString.Contains(text[i].ToString()))
                        {
                            dummyString = text[i].ToString();
                            freq++;
                        }
                    }
                }
                //temp = (double)freq / (double)text.Length;
                //temp = temp * (double)10;
                //temp = Math.Round(temp);
                score = (int)freq;
                return score;
            }
            catch (Exception ex)
            { throw ex; }
        }
        public static bool isEqualStrings(string fstring, string sstring)
        {
            fstring = fstring.Trim();
            sstring = sstring.Trim();
            Stemmer stemer1 = new Stemmer();
            if (fstring == sstring ||
                stemer1.stemTerm(fstring) == sstring ||
                stemer1.stemTerm(sstring) == fstring ||
                stemer1.stemTerm(fstring) == stemer1.stemTerm(sstring)
                // stemer1.stemTerm(fstring).Contains( sstring) ||
                // stemer1.stemTerm(sstring).Contains( fstring) ||
                // stemer1.stemTerm(fstring).Contains( stemer1.stemTerm(sstring)) ||
                // stemer1.stemTerm(sstring).Contains( fstring) ||
                // stemer1.stemTerm(fstring).Contains( sstring) ||
                //  stemer1.stemTerm(sstring).Contains( stemer1.stemTerm(fstring))                
                ) { return true; }
            else { return false; }
        }
        public static int Relation_headlineWVM(string abstractSentence, string currentSentence, Hashtable ht)
        {
            try
            {
                abstractSentence = Parser.parse_Sentence(abstractSentence);
                currentSentence = Parser.parse_Sentence(currentSentence);
                abstractSentence = Parser.remove_fullStop(abstractSentence);
                currentSentence = Parser.remove_fullStop(currentSentence);
                string[] text = abstractSentence.Split(' ');
                text = text.Distinct().ToArray();
                string[] list = currentSentence.Split(' ');
                string dummyString = "";
                int score = 0;
                double temp = 0;
                for (int i = 0; i < text.Length; i++)
                {
                    for (int j = 0; j < list.Length; j++)
                    {
                        if (isEqualStrings(text[i].ToString(), list[j].ToString()) && !dummyString.Contains(text[i].ToString()))
                        {
                            string term = text[i].ToString();
                            dummyString = text[i].ToString();
                            double testRes = 10000 * Convert.ToInt32(ht[term.Replace(" ", "").ToLower()]) / Convert.ToInt32(ht["my_total"]);
                            temp = temp + testRes;
                        }
                    }
                }
                temp = Math.Round(temp);
                score = (int)temp;
                return score;
            }
            catch (Exception ex)
            { throw ex; }
        }
        public static int avg_sentence_length(string[] Corpus)
        {
            try
            {
                double len = 0;
                int[] array = new int[Corpus.Length];
                int i = 0;
                foreach (string ss in Corpus)
                {
                    string[] temp = ss.Split(' ');
                    array[i] = temp.Length;
                    i++;
                }
                for (int j = 0; j < array.Length; j++)
                {
                    len = len + array[j];
                }
                len = len / (array.Length - 1);
                return (int)len;
            }
            catch (Exception ex)
            { throw ex; }
        }
        public static int Relation_headlineClusterW(string abstractSentence, string currentSentence, Hashtable ht)
        {
            try
            {
                string[] text = abstractSentence.Split('.');
                text = text.Distinct().ToArray();
                int score = 0;
                int max_score = 0;
                foreach (string sentence in text)
                {
                    if (!String.IsNullOrEmpty(sentence) && sentence != "")
                    {
                        score = Relation_headlineWVM(sentence, currentSentence, ht);
                        if (score > max_score)
                        {
                            max_score = score;
                        }
                    }
                }
                return max_score;
            }
            catch (Exception ex)
            { throw ex; }
        }
        public static int Relation_headlineCluster(string fsentence, string xSentence, Hashtable ht)
        {
            try
            {
                string[] text = fsentence.Split('.');
                text = text.Distinct().ToArray();
                int score = 0;
                int max_score = 0;
                foreach (string sentence in text)
                {
                    if (!String.IsNullOrEmpty(sentence) && sentence != "")
                    {
                        score = Relation_headline(sentence, xSentence);
                        if (score > max_score)
                        {
                            max_score = score;
                        }
                    }
                }
                return max_score;
            }
            catch (Exception ex)
            { throw ex; }
        }
        public static int Relation_headlineClusterCount(string fsentence, string xSentence, Hashtable ht)
        {
            try
            {
                string[] text = fsentence.Split('.');
                text = text.Distinct().ToArray();
                int total_score = 0;
                int current_score = 0;
                foreach (string sentence in text)
                {
                    if (!String.IsNullOrEmpty(sentence) && sentence != "")
                    {
                        current_score = Relation_headline(sentence, xSentence);
                        if (current_score > 0)
                        {
                            total_score++;
                        }
                    }
                }
                return total_score;
            }
            catch (Exception ex)
            { throw ex; }
        }
    }
}

